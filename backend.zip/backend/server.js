const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const mongoose = require("mongoose");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

mongoose
  .connect("mongodb://localhost:27017/userdb", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("Failed to connect to MongoDB:", err));

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  phone: { type: String, required: true },
  age: { type: Number, required: true },
  address: { type: String, required: true },
  email: { type: String, required: true, unique: true },
});

const User = mongoose.model("User", userSchema);

// Routes

// Get all users
app.get("/users", async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch users" });
  }
});

// Add a new user
app.post("/users", async (req, res) => {
  const { name, phone, age, address, email } = req.body;

  if (!name || !phone || !age || !address || !email) {
    return res.status(400).json({ error: "All fields are required" });
  }

  try {
    const newUser = new User({ name, phone, age, address, email });
    await newUser.save();
    res.json({ message: "User added successfully!" });
  } catch (err) {
    res.status(500).json({ error: "Failed to add user. Ensure email is unique." });
  }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
